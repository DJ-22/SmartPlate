create
    definer = root@localhost procedure sp_LogWaste(IN p_batch_id int, IN p_quantity decimal(6, 2))
BEGIN
    DECLARE v_ingredient_id INT;
    SELECT ingredient_id INTO v_ingredient_id FROM Inventory_Batches
    WHERE inventory_batch_id = p_batch_id;

    INSERT INTO Waste_Records (quantity, timestamp, inventory_batch_id)
    VALUES (p_quantity, NOW(), p_batch_id);

    UPDATE Ingredients SET quantity = GREATEST(0, quantity - p_quantity)
    WHERE ingredient_id = v_ingredient_id;
END;

