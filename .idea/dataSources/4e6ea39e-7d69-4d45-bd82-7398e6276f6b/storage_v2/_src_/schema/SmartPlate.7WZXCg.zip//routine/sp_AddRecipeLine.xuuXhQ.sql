create
    definer = root@localhost procedure sp_AddRecipeLine(IN p_item_id int, IN p_ingredient_id int,
                                                        IN p_quantity decimal(6, 2), IN p_unit varchar(15))
BEGIN
    INSERT INTO Recipes (item_id, ingredient_id, quantity, unit)
    VALUES (p_item_id, p_ingredient_id, p_quantity, p_unit)
    ON DUPLICATE KEY UPDATE quantity = p_quantity;
END;

