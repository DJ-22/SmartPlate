create definer = root@localhost trigger trg_after_batch_update
    after update
    on Inventory_Batches
    for each row
BEGIN
    IF NEW.quantity <= 0 THEN
        DELETE FROM Inventory_Batches
        WHERE inventory_batch_id = NEW.inventory_batch_id;
    END IF;
END;

