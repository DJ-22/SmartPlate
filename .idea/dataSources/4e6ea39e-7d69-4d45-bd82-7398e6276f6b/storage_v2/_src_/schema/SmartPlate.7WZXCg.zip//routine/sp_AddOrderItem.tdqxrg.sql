create
    definer = root@localhost procedure sp_AddOrderItem(IN p_order_id int, IN p_item_id int, IN p_quantity decimal(6, 2))
BEGIN
    DECLARE v_price DECIMAL(6,2);
    SELECT price INTO v_price FROM Items WHERE item_id = p_item_id;

    INSERT INTO Menu_Orders_Items (menu_order_id, item_id, quantity, status)
    VALUES (p_order_id, p_item_id, p_quantity, 0);

    UPDATE Menu_Orders SET price = price + (v_price * p_quantity)
    WHERE menu_order_id = p_order_id;
END;

