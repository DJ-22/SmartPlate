create
    definer = root@localhost procedure sp_RecordWeather(IN p_date datetime, IN p_temperature decimal(4, 2),
                                                        IN p_humidity decimal(5, 2))
BEGIN
    INSERT INTO Weather_Data (date, temperature, humidity)
    VALUES (p_date, p_temperature, p_humidity)
    ON DUPLICATE KEY UPDATE temperature = p_temperature, humidity = p_humidity;
END;

