create
    definer = root@localhost procedure sp_RecordSale(IN p_order_id int, IN p_item_id int, IN p_quantity decimal(6, 2),
                                                     IN p_occasion varchar(100))
BEGIN
    DECLARE v_occasion_id INT;

    INSERT IGNORE INTO Occasions (name) VALUES (p_occasion);
    SELECT occasion_id INTO v_occasion_id FROM Occasions WHERE name = p_occasion LIMIT 1;

    INSERT INTO Sales_History (quantity, item_id, menu_order_id, occasion_id)
    VALUES (p_quantity, p_item_id, p_order_id, v_occasion_id);
END;

