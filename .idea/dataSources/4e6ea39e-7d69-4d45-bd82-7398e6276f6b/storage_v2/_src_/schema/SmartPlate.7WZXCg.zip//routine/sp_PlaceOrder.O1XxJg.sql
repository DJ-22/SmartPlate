create
    definer = root@localhost procedure sp_PlaceOrder(IN p_user_id int)
BEGIN
    INSERT INTO Menu_Orders (order_time, price, user_id)
    VALUES (NOW(), 0, p_user_id);
END;

