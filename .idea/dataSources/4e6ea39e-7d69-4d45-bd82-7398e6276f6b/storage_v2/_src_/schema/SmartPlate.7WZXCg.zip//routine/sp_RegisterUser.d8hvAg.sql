create
    definer = root@localhost procedure sp_RegisterUser(IN p_username varchar(100), IN p_email varchar(100),
                                                       IN p_pwd_hash varchar(255), IN p_role_name varchar(100),
                                                       IN p_user_type varchar(20), IN p_name varchar(100),
                                                       IN p_salary decimal(15, 2))
BEGIN
    DECLARE v_role_id INT;
    DECLARE v_user_id INT;

    INSERT IGNORE INTO Roles (name) VALUES (p_role_name);
    SELECT role_id INTO v_role_id FROM Roles WHERE name = p_role_name LIMIT 1;

    INSERT INTO Users (username, email, password_hash, last_login, role_id)
    VALUES (p_username, p_email, p_pwd_hash, NOW(), v_role_id);

    SET v_user_id = LAST_INSERT_ID();

    IF p_user_type = 'customer' THEN
        INSERT INTO Customers (name, visit_frequency, user_id)
        VALUES (p_name, 0, v_user_id);
    ELSEIF p_user_type = 'employee' THEN
        INSERT INTO Employees (hire_date, salary, user_id)
        VALUES (NOW(), p_salary, v_user_id);
    END IF;
END;

