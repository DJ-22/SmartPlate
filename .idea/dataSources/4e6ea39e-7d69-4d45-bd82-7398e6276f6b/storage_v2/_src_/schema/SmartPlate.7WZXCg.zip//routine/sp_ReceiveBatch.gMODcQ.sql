create
    definer = root@localhost procedure sp_ReceiveBatch(IN p_ingredient_id int, IN p_supplier_id int,
                                                       IN p_quantity decimal(6, 2), IN p_unit varchar(15),
                                                       IN p_cost decimal(10, 2), IN p_expiry_date datetime)
BEGIN
    INSERT INTO Inventory_Batches
        (purchase_date, expiry_date, quantity, unit, cost, status, supplier_id, ingredient_id)
    VALUES (NOW(), p_expiry_date, p_quantity, p_unit, p_cost, 1, p_supplier_id, p_ingredient_id);

    -- update ingredient running total
    UPDATE Ingredients SET quantity = quantity + p_quantity
    WHERE ingredient_id = p_ingredient_id;
END;

