create
    definer = root@localhost procedure sp_LogCompliance(IN p_status tinyint, IN p_description varchar(100))
BEGIN
    INSERT INTO Compliance_Records (inspection_date, status, description)
    VALUES (NOW(), p_status, p_description);
END;

