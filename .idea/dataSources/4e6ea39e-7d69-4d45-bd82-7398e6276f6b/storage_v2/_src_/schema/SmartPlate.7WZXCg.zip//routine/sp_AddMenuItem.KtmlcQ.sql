create
    definer = root@localhost procedure sp_AddMenuItem(IN p_name varchar(100), IN p_description varchar(100),
                                                      IN p_price decimal(6, 2), IN p_prep_time int,
                                                      IN p_category varchar(100))
BEGIN
    DECLARE v_category_id INT;

    INSERT IGNORE INTO Category (name) VALUES (p_category);
    SELECT category_id INTO v_category_id FROM Category WHERE name = p_category LIMIT 1;

    INSERT INTO Items (name, description, price, prep_time, is_available, category_id)
    VALUES (p_name, p_description, p_price, p_prep_time, 1, v_category_id);
END;

