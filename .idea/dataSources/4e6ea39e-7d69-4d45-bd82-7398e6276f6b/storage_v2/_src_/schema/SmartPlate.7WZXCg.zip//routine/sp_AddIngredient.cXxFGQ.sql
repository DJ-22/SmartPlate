create
    definer = root@localhost procedure sp_AddIngredient(IN p_name varchar(100), IN p_unit varchar(15),
                                                        IN p_min_stock decimal(6, 2), IN p_allergen varchar(100))
BEGIN
    DECLARE v_allergen_id INT;

    -- insert allergen if it doesn't exist
    INSERT IGNORE INTO Allergens (name) VALUES (p_allergen);
    SELECT allergen_id INTO v_allergen_id FROM Allergens WHERE name = p_allergen LIMIT 1;

    INSERT INTO Ingredients (name, unit, min_stock, quantity, allergen_id)
    VALUES (p_name, p_unit, p_min_stock, 0, v_allergen_id);
END;

